=========================================================
  GHOST CHAT - CPU COMPATIBILITY & TROUBLESHOOTING
=========================================================

"Note: Ghost Chat requires the free .NET 8 Desktop Runtime to run. If the app doesn't open, you can download it directly from Microsoft here: https://dotnet.microsoft.com/en-us/download/dotnet/8.0"

Ghost Chat uses LLamaSharp, which requires native C++ libraries 
to run AI models. By default, this app ships with the AVX2 version 
of these libraries because AVX2 is supported by 95% of all CPUs 
made after 2013 (Intel 4th Gen and AMD Ryzen). 

If the app crashes immediately when you click "Load Model" 
(usually with an error like "The type initializer for LLama.Native.NativeApi threw an exception"), 
it means your CPU does not support AVX2. 

Do not worry! We have included the libraries for older and newer CPUs 
in the 'runtimes' folder. 

---------------------------------------------------------
HOW TO FIX (IF YOU GET A DLL CRASH):
---------------------------------------------------------

1. Look inside the 'runtimes\win-x64\native\' folder. You will see 4 folders:
   - avx2    (Default - Most modern PCs)
   - avx512  (High-end server & AMD Ryzen 7000/9000 CPUs)
   - avx     (Older PCs, around 2011-2013)
   - noavx   (Very old PCs)

2. Find the folder that matches your CPU. If you aren't sure, try 'avx' or 'noavx'.

3. Open that folder, select ALL the .dll files inside it, and copy them.

4. Paste them into the MAIN folder (the same folder where GhostChat64.exe is located).
   Windows will ask if you want to replace the existing files. Click "Yes" to replace them.

5. Launch GhostChat64.exe again. It should now work perfectly!

---------------------------------------------------------
WHY DID WE DO THIS?
---------------------------------------------------------
Because downloading 4 different versions of the app (150MB+ each) 
is a waste of space. This way, the app stays tiny (35MB), and you only 
swap the files if your CPU needs it. 

Note: If you replace the DLLs, do not rename them. Just replace them.