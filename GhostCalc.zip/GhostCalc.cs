﻿using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;

public class Program {
    [STAThread]
    static void Main() {
        bool createdNew = false;
        Mutex mutex = null;
        try { mutex = new Mutex(false, @"Local\GhostCalc_SingleInstance", out createdNew); }
        catch { createdNew = true; mutex = null; }
        if (!createdNew) { if (mutex != null) { try { mutex.Close(); } catch { } } return; }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try { Application.Run(new GhostCalcContext(mutex)); }
        catch (Exception ex) { MessageBox.Show("Ghost Calc failed to start:\n" + ex.Message, "Ghost Calc"); }
    }
}

// ----------------------------------------------------------------------
// Shared app icon
// ----------------------------------------------------------------------
public static class CalcIcon {
    private static Icon _cached = null;
    public static Icon Get() {
        if (_cached != null) return _cached;
        try {
            string[] names = new string[] { "ghostcalc.ico", "gn.ico" };
            string appDir = Path.GetDirectoryName(Application.ExecutablePath);
            foreach (string n in names) {
                string p = Path.Combine(appDir, n);
                if (File.Exists(p)) {
                    try { _cached = new Icon(p); return _cached; } catch { }
                }
            }
            _cached = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        } catch { }
        return _cached;
    }
}

// ----------------------------------------------------------------------
// Settings
// ----------------------------------------------------------------------
public class CalcSettings {
    public bool CloseAfterInsert = false;
    public bool CopyOnInsert = true;
    public bool AlwaysOnTop = true;
    public bool DigitGrouping = false;
}

// ----------------------------------------------------------------------
// Unit conversion table
// ----------------------------------------------------------------------
public class UnitCat {
    public string Name;
    public string[] Units;
    public double[] Factors;
    public bool IsTemp;
    public UnitCat(string name, string[] units, double[] factors) {
        Name = name; Units = units; Factors = factors; IsTemp = false;
    }
    public UnitCat(string name, string[] units) {
        Name = name; Units = units; Factors = null; IsTemp = true;
    }
}

// ----------------------------------------------------------------------
// Tray context
// ----------------------------------------------------------------------
public class GhostCalcContext : ApplicationContext {
    private NotifyIcon _tray;
    private CalculatorForm _calcForm;
    private Mutex _mutex;
    private string _settingsFile;
    public CalcSettings Settings = new CalcSettings();

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    public GhostCalcContext(Mutex mutex) {
        _mutex = mutex;
        _settingsFile = Path.Combine(Application.StartupPath, "ghostcalc.ini");
        LoadSettings();

        _calcForm = new CalculatorForm(this);

        BuildTray();

        _calcForm.Show();
        _calcForm.Activate();
    }

    private void BuildTray() {
        _tray = new NotifyIcon();
        try { _tray.Icon = CalcIcon.Get(); } catch { }
        if (_tray.Icon == null) _tray.Icon = SystemIcons.Application;
        _tray.Text = "Ghost Calc";
        _tray.Visible = true;
        _tray.DoubleClick += (s, e) => ShowCalculator();

        ContextMenuStrip menu = new ContextMenuStrip();
        menu.Items.Add("Open Calculator", null, (s, e) => ShowCalculator());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Settings...", null, (s, e) => ShowSettings());
        menu.Items.Add("Help Contents", null, (s, e) => OpenHelpFile());
        menu.Items.Add("About...", null, (s, e) => ShowAbout());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (s, e) => ExitApp());

        _tray.ContextMenuStrip = menu;
    }

    public void ShowCalculator() {
        IntPtr fg = GetForegroundWindow();
        if (fg != IntPtr.Zero && fg != _calcForm.Handle) {
            _calcForm.SetTarget(fg);
        }
        if (!_calcForm.Visible) _calcForm.Show();
        if (_calcForm.WindowState == FormWindowState.Minimized) _calcForm.WindowState = FormWindowState.Normal;
        _calcForm.Activate();
        _calcForm.BringToFront();
    }

    private void ShowSettings() {
        using (SettingsDialog dlg = new SettingsDialog(Settings)) {
            if (dlg.ShowDialog() == DialogResult.OK) {
                Settings = dlg.Result;
                _calcForm.ApplySettings();
                SaveSettings();
            }
        }
    }

    public void OpenHelpFile() {
        try {
            string helpPath = Path.Combine(Application.StartupPath, "help.html");
            if (File.Exists(helpPath)) System.Diagnostics.Process.Start(helpPath);
            else MessageBox.Show("Help file not found.\n\nExpected location:\n" + helpPath, "Help Missing", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        } catch (Exception ex) {
            MessageBox.Show("Could not open help file:\n" + ex.Message, "Error");
        }
    }

    public void ShowAbout() {
        Form dlg = new Form();
        dlg.Text = "About Ghost Calc";
        dlg.Icon = CalcIcon.Get();
        dlg.TopMost = true;
        dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
        dlg.StartPosition = FormStartPosition.CenterScreen;
        dlg.MinimizeBox = false; dlg.MaximizeBox = false; dlg.ShowInTaskbar = false;
        dlg.BackColor = Color.White;
        dlg.ClientSize = new Size(470, 390);

        PictureBox pic = new PictureBox();
        pic.SizeMode = PictureBoxSizeMode.Zoom;
        pic.Location = new Point(20, 25);
        pic.Size = new Size(105, 105);
        pic.BackColor = Color.Transparent;
        string appDir = Path.GetDirectoryName(Application.ExecutablePath);
        string[] imageNames = new string[] { "ghostcalc.png", "ghostcalculate.png", "gn.png" };
        string imgPath = null;
        foreach (string n in imageNames) { string c = Path.Combine(appDir, n); if (File.Exists(c)) { imgPath = c; break; } }
        if (imgPath != null) {
            try { using (FileStream fs = new FileStream(imgPath, FileMode.Open, FileAccess.Read, FileShare.Read)) { using (Image src = Image.FromStream(fs)) { pic.Image = new Bitmap(src); } } } catch { }
        }
        dlg.Controls.Add(pic);

        Label lblTitle = new Label(); lblTitle.Text = "Ghost Calc"; lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold); lblTitle.ForeColor = Color.FromArgb(30, 30, 30); lblTitle.Location = new Point(145, 25); lblTitle.Size = new Size(310, 32); dlg.Controls.Add(lblTitle);
        Label lblVer = new Label(); lblVer.Text = "Version 1.0"; lblVer.Font = new Font("Segoe UI", 9F, FontStyle.Italic); lblVer.ForeColor = Color.FromArgb(110, 110, 110); lblVer.Location = new Point(147, 60); lblVer.Size = new Size(310, 20); dlg.Controls.Add(lblVer);
        Label lblDesc = new Label(); lblDesc.Text = "A calculator that can type its answer into any window."; lblDesc.Font = new Font("Segoe UI", 9F); lblDesc.ForeColor = Color.FromArgb(60, 60, 60); lblDesc.Location = new Point(147, 82); lblDesc.Size = new Size(310, 50); dlg.Controls.Add(lblDesc);

        Panel sep = new Panel(); sep.BackColor = Color.FromArgb(220, 220, 220); sep.Location = new Point(20, 140); sep.Size = new Size(430, 1); dlg.Controls.Add(sep);

        Label lblEnjoy = new Label(); lblEnjoy.Text = "📝 Enjoying Ghost Calc?"; lblEnjoy.Font = new Font("Segoe UI Emoji", 10F, FontStyle.Bold); lblEnjoy.ForeColor = Color.FromArgb(0, 120, 0); lblEnjoy.Location = new Point(20, 152); lblEnjoy.Size = new Size(430, 22); dlg.Controls.Add(lblEnjoy);
        Label lblBody = new Label(); lblBody.Text = "Ghost Calc is free, and it always will be. If it's been saving you keystrokes, a small donation keeps the ink flowing."; lblBody.Font = new Font("Segoe UI", 9F); lblBody.ForeColor = Color.FromArgb(60, 60, 60); lblBody.Location = new Point(20, 178); lblBody.Size = new Size(430, 50); dlg.Controls.Add(lblBody);

        Button btnVisit = new Button(); btnVisit.Text = "Visit the website →"; btnVisit.Location = new Point(20, 235); btnVisit.Size = new Size(160, 30);
        btnVisit.Click += (s, e) => { try { System.Diagnostics.Process.Start("https://ghostbundle.github.io"); } catch { } }; dlg.Controls.Add(btnVisit);

        Button btnOk = new Button(); btnOk.Text = "OK"; btnOk.DialogResult = DialogResult.OK; btnOk.Location = new Point(375, 235); btnOk.Size = new Size(75, 30);
        dlg.Controls.Add(btnOk); dlg.AcceptButton = btnOk; dlg.CancelButton = btnOk;

        Button btnSupport = new Button(); btnSupport.Text = "💗 Support this project →"; btnSupport.Location = new Point(145, 275); btnSupport.Size = new Size(180, 32);
        btnSupport.Font = new Font("Segoe UI Emoji", 9F, FontStyle.Bold); btnSupport.BackColor = Color.FromArgb(255, 90, 138); btnSupport.ForeColor = Color.White;
        btnSupport.FlatStyle = FlatStyle.Flat; btnSupport.FlatAppearance.BorderSize = 0; btnSupport.Cursor = Cursors.Hand;
        btnSupport.Click += (s, e) => { try { System.Diagnostics.Process.Start("https://square.link/u/EmMBiWhn"); } catch { } }; dlg.Controls.Add(btnSupport);

        Label lblBy = new Label(); lblBy.Text = "Developed by adaia.daci"; lblBy.Font = new Font("Segoe UI", 8F, FontStyle.Italic); lblBy.ForeColor = Color.FromArgb(150, 150, 150); lblBy.TextAlign = ContentAlignment.MiddleCenter; lblBy.Location = new Point(20, 320); lblBy.Size = new Size(430, 18); dlg.Controls.Add(lblBy);
        Label lblMagnific = new Label(); lblMagnific.Text = "Ghost image Designed by Magnific - www.magnific.com"; lblMagnific.Font = new Font("Segoe UI", 7F); lblMagnific.ForeColor = Color.FromArgb(180, 180, 180); lblMagnific.TextAlign = ContentAlignment.MiddleCenter; lblMagnific.Location = new Point(20, 340); lblMagnific.Size = new Size(430, 16); dlg.Controls.Add(lblMagnific);

        dlg.ActiveControl = btnSupport;
        dlg.FormClosed += (s, e) => { try { if (pic.Image != null) { pic.Image.Dispose(); pic.Image = null; } } catch { } };
        try { dlg.ShowDialog(); } catch { }
        try { dlg.Dispose(); } catch { }
    }

    private void ExitApp() {
        _calcForm.AllowClose = true;
        try { _calcForm.Close(); } catch { }
        try { if (_tray != null) { _tray.Visible = false; _tray.Dispose(); } } catch { }
        SaveSettings();
        try { if (_mutex != null) _mutex.Close(); } catch { }
        ExitThread();
    }

    private void LoadSettings() {
        try {
            if (File.Exists(_settingsFile)) {
                foreach (string line in File.ReadAllLines(_settingsFile)) {
                    if (line.StartsWith("CloseAfterInsert=")) Settings.CloseAfterInsert = line.Substring(17) == "1";
                    else if (line.StartsWith("CopyOnInsert=")) Settings.CopyOnInsert = line.Substring(13) == "1";
                    else if (line.StartsWith("AlwaysOnTop=")) Settings.AlwaysOnTop = line.Substring(12) == "1";
                    else if (line.StartsWith("DigitGrouping=")) Settings.DigitGrouping = line.Substring(14) == "1";
                }
            }
        } catch { }
    }

    private void SaveSettings() {
        try {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CloseAfterInsert=" + (Settings.CloseAfterInsert ? "1" : "0"));
            sb.AppendLine("CopyOnInsert=" + (Settings.CopyOnInsert ? "1" : "0"));
            sb.AppendLine("AlwaysOnTop=" + (Settings.AlwaysOnTop ? "1" : "0"));
            sb.AppendLine("DigitGrouping=" + (Settings.DigitGrouping ? "1" : "0"));
            File.WriteAllText(_settingsFile, sb.ToString(), new UTF8Encoding(false));
        } catch { }
    }
}

// ----------------------------------------------------------------------
// Main calculator window
// ----------------------------------------------------------------------
public class CalculatorForm : Form {
    private GhostCalcContext _ctx;
    public bool AllowClose = false;

    private IntPtr _targetWindow = IntPtr.Zero;
    private string _targetTitle = "(none)";

    private string _display = "0";
    private double _current = 0;
    private double _operand = 0;
    private string _pendingOp = "";
    private string _lastOp = "";
    private double _lastOpValue = 0;
    private bool _isNewEntry = true;
    private double _memory = 0;
    private bool _isError = false;

    private ClipLabel _expressionLabel;
    private string _expressionChain = "";
    private Panel _leftPanel;
    private ClipLabel _leftExpressionLabel;
    private bool _leftPanelExpanded = false;
    private const int LeftPanelW = 244;

    private Label _displayLabel;
    private Label _targetLabel;
    private Button _btnInsert, _btnCopy, _btnClose;

    private Panel _activeWorksheet = null;
    private Panel _mortgagePanel;
    private Panel _fdPanel;
    private Panel _rsPanel;
    private Panel _unitPanel;
    private Panel _datePanel;

    // Mortgage fields
    private TextBox _mortPrincipal, _mortRate, _mortTerm, _mortPayment;
    private Label _mortStatus;

    // Fixed deposit fields
    private TextBox _fdPrincipal, _fdRate, _fdTerm, _fdMaturity;
    private ComboBox _fdCompounding;
    private Label _fdStatus;

    // Recurring saver fields — now includes initial Principal
    private TextBox _rsPrincipal, _rsDeposit, _rsRate, _rsTerm, _rsMaturity;
    private ComboBox _rsCompounding;
    private Label _rsStatus;

    // Unit conversion fields
    private ComboBox _ucCategory, _ucFrom, _ucTo;
    private TextBox _ucFromValue, _ucToValue;
    private Label _ucStatus;

    // Date calc fields
    private ComboBox _dcMode;
    private DateTimePicker _dcFrom, _dcTo, _dcStart;
    private TextBox _dcAmount;
    private ComboBox _dcUnit, _dcDirection;
    private Button _dcCalcBtn;
    private Label _dcStatus;
    private Label _dcFromLbl, _dcToLbl, _dcStartLbl, _dcAmountLbl, _dcUnitLbl, _dcDirectionLbl;

    private MenuItem _mnuMortgage, _mnuFD, _mnuRS, _mnuUnit, _mnuDate;

    private static readonly Color WarmBg = Color.FromArgb(0xFD, 0xFA, 0xF3);
    private static readonly Color WarmCardBg = Color.FromArgb(0xFB, 0xF7, 0xEE);
    private static readonly Color WarmButtonBg = Color.FromArgb(0xF5, 0xEE, 0xDC);
    private static readonly Color WarmButtonHover = Color.FromArgb(0xEA, 0xDF, 0xC2);
    private static readonly Color WarmButtonDown = Color.FromArgb(0xDD, 0xD1, 0xB5);
    private static readonly Color WarmButtonBorder = Color.FromArgb(0xD4, 0xC4, 0xA0);
    private static readonly Color WarmText = Color.FromArgb(0x2B, 0x21, 0x18);
    private static readonly Color WarmAccent = Color.FromArgb(0xA6, 0x7C, 0x52);
    private static readonly Color WarmMuted = Color.FromArgb(0x8B, 0x7A, 0x5C);

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT { public uint type; public InputUnion U; }
    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion {
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public KEYBDINPUT ki;
        [FieldOffset(0)] public HARDWAREINPUT hi;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
    [StructLayout(LayoutKind.Sequential)]
    private struct HARDWAREINPUT { public uint uMsg; public ushort wParamL; public ushort wParamH; }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

    private const uint INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;
    private const uint KEYEVENTF_UNICODE = 0x0004;
    private const ushort VK_RETURN = 0x0D;
    private const ushort VK_TAB = 0x09;

    private const int CLIENT_W_CLOSED = 260;
    private const int CLIENT_W_OPEN = 540;
    private const int CLIENT_H = 362;

    private static readonly string[] CompoundingOptions = new string[] { "Daily", "Monthly", "Quarterly", "Semi-annually", "Annually" };

    private static readonly UnitCat[] UnitCategories = new UnitCat[] {
        new UnitCat("Length",
            new string[] { "Meters", "Kilometers", "Centimeters", "Millimeters", "Miles", "Yards", "Feet", "Inches" },
            new double[] { 1, 1000, 0.01, 0.001, 1609.344, 0.9144, 0.3048, 0.0254 }),
        new UnitCat("Weight",
            new string[] { "Kilograms", "Grams", "Milligrams", "Pounds", "Ounces", "Stones", "Metric tons" },
            new double[] { 1, 0.001, 0.000001, 0.45359237, 0.028349523125, 6.35029318, 1000 }),
        new UnitCat("Temperature",
            new string[] { "Celsius", "Fahrenheit", "Kelvin" }),
        new UnitCat("Volume",
            new string[] { "Liters", "Milliliters", "Cubic meters", "Gallons (US)", "Quarts (US)", "Pints (US)", "Cups (US)", "Fluid ounces (US)" },
            new double[] { 1, 0.001, 1000, 3.785411784, 0.946352946, 0.473176473, 0.2365882365, 0.0295735295625 }),
        new UnitCat("Area",
            new string[] { "Square meters", "Square kilometers", "Square feet", "Square yards", "Acres", "Hectares" },
            new double[] { 1, 1000000, 0.09290304, 0.83612736, 4046.8564224, 10000 }),
        new UnitCat("Speed",
            new string[] { "Meters per second", "Kilometers per hour", "Miles per hour", "Knots", "Feet per second" },
            new double[] { 1, 0.277777778, 0.44704, 0.514444444, 0.3048 }),
        new UnitCat("Time",
            new string[] { "Seconds", "Minutes", "Hours", "Days", "Weeks" },
            new double[] { 1, 60, 3600, 86400, 604800 }),
        new UnitCat("Data",
            new string[] { "Bytes", "Kilobytes", "Megabytes", "Gigabytes", "Terabytes", "Bits" },
            new double[] { 1, 1024, 1048576, 1073741824, 1099511627776, 0.125 }),
    };

    public CalculatorForm(GhostCalcContext ctx) {
        _ctx = ctx;
        BuildUI();
        ApplySettings();
        UpdateDisplay();
    }

    private void BuildUI() {
        this.Text = "Ghost Calc";
        this.Icon = CalcIcon.Get();
        this.FormBorderStyle = FormBorderStyle.FixedSingle;
        this.MaximizeBox = false;
        this.StartPosition = FormStartPosition.CenterScreen;
        this.BackColor = WarmBg;
        this.Font = new Font("Segoe UI", 9);
        this.ClientSize = new Size(CLIENT_W_CLOSED, CLIENT_H);
        this.KeyPreview = true;
        this.KeyDown += CalculatorForm_KeyDown;
        this.Deactivate += CalculatorForm_Deactivate;
        this.FormClosing += CalculatorForm_FormClosing;

        MainMenu menu = new MainMenu();
        MenuItem viewMenu = new MenuItem("&View");
        viewMenu.MenuItems.Add("&Basic\tCtrl+F4", (s, e) => FoldAllPanels());
        viewMenu.MenuItems.Add(new MenuItem("-"));
        _mnuMortgage = new MenuItem("&Mortgage repayment", (s, e) => ShowWorksheetPanel(_mortgagePanel));
        _mnuMortgage.RadioCheck = true;
        viewMenu.MenuItems.Add(_mnuMortgage);
        _mnuFD = new MenuItem("&Fixed deposit", (s, e) => ShowWorksheetPanel(_fdPanel));
        _mnuFD.RadioCheck = true;
        viewMenu.MenuItems.Add(_mnuFD);
        _mnuRS = new MenuItem("&Recurring saver", (s, e) => ShowWorksheetPanel(_rsPanel));
        _mnuRS.RadioCheck = true;
        viewMenu.MenuItems.Add(_mnuRS);
        viewMenu.MenuItems.Add(new MenuItem("-"));
        _mnuUnit = new MenuItem("&Unit conversion", (s, e) => ShowWorksheetPanel(_unitPanel));
        _mnuUnit.RadioCheck = true;
        viewMenu.MenuItems.Add(_mnuUnit);
        _mnuDate = new MenuItem("&Date calculation", (s, e) => ShowWorksheetPanel(_datePanel));
        _mnuDate.RadioCheck = true;
        viewMenu.MenuItems.Add(_mnuDate);
        menu.MenuItems.Add(viewMenu);

        MenuItem editMenu = new MenuItem("&Edit");
        editMenu.MenuItems.Add("&Copy display\tCtrl+C", (s, e) => DoCopy());
        menu.MenuItems.Add(editMenu);

        MenuItem helpMenu = new MenuItem("&Help");
        helpMenu.MenuItems.Add("Help &Contents", (s, e) => _ctx.OpenHelpFile());
        helpMenu.MenuItems.Add(new MenuItem("-"));
        helpMenu.MenuItems.Add("&About", (s, e) => _ctx.ShowAbout());
        menu.MenuItems.Add(helpMenu);

        this.Menu = menu;

        _expressionLabel = new ClipLabel();
        _expressionLabel.Location = new Point(8, 8);
        _expressionLabel.Size = new Size(244, 18);
        _expressionLabel.Font = new Font("Segoe UI", 8.5F);
        _expressionLabel.ForeColor = WarmMuted;
        _expressionLabel.BackColor = WarmBg;
        _expressionLabel.Text = "";
        this.Controls.Add(_expressionLabel);

        _leftPanel = new Panel();
        _leftPanel.Location = new Point(0, 0);
        _leftPanel.Size = new Size(LeftPanelW, CLIENT_H);
        _leftPanel.BackColor = WarmBg;
        _leftPanel.Visible = false;
        this.Controls.Add(_leftPanel);

        Panel divider = new Panel();
        divider.Location = new Point(LeftPanelW - 1, 0);
        divider.Size = new Size(1, CLIENT_H);
        divider.BackColor = WarmButtonBorder;
        _leftPanel.Controls.Add(divider);

        _leftExpressionLabel = new ClipLabel();
        _leftExpressionLabel.Location = new Point(8, 8);
        _leftExpressionLabel.Size = new Size(LeftPanelW - 16, 18);
        _leftExpressionLabel.Font = new Font("Segoe UI", 8.5F);
        _leftExpressionLabel.ForeColor = WarmMuted;
        _leftExpressionLabel.BackColor = WarmBg;
        _leftExpressionLabel.Text = "";
        _leftPanel.Controls.Add(_leftExpressionLabel);

        _displayLabel = new Label();
        _displayLabel.Location = new Point(8, 26);
        _displayLabel.Size = new Size(244, 44);
        _displayLabel.TextAlign = ContentAlignment.MiddleRight;
        _displayLabel.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
        _displayLabel.ForeColor = WarmText;
        _displayLabel.BackColor = WarmCardBg;
        _displayLabel.Text = "0";
        _displayLabel.Padding = new Padding(0, 0, 8, 0);
        this.Controls.Add(_displayLabel);

        _targetLabel = new Label();
        _targetLabel.Location = new Point(8, 74);
        _targetLabel.Size = new Size(244, 14);
        _targetLabel.TextAlign = ContentAlignment.MiddleRight;
        _targetLabel.Font = new Font("Segoe UI", 7F, FontStyle.Italic);
        _targetLabel.ForeColor = WarmMuted;
        _targetLabel.BackColor = Color.Transparent;
        _targetLabel.Text = "Target: (none)";
        this.Controls.Add(_targetLabel);

        BuildButtonGrid();
        BuildActionRow();

        BuildMortgagePanel();
        BuildFDPanel();
        BuildRSPanel();
        BuildUnitPanel();
        BuildDatePanel();
    }

    private void BuildButtonGrid() {
        int[] cols = new int[] { 8, 58, 108, 158, 208 };
        int[] rows = new int[] { 94, 130, 166, 202, 238, 274 };
        int bw = 46, bh = 32;

        AddButton("MC", cols[0], rows[0], bw, bh, (s, e) => { _memory = 0; });
        AddButton("MR", cols[1], rows[0], bw, bh, (s, e) => { _current = _memory; _display = FormatNumber(_memory); _isNewEntry = true; UpdateDisplay(); });
        AddButton("MS", cols[2], rows[0], bw, bh, (s, e) => { ParseCurrent(); _memory = _current; });
        AddButton("M+", cols[3], rows[0], bw, bh, (s, e) => { ParseCurrent(); _memory += _current; });
        AddButton("M-", cols[4], rows[0], bw, bh, (s, e) => { ParseCurrent(); _memory -= _current; });

        AddButton("←", cols[0], rows[1], bw, bh, (s, e) => Backspace());
        AddButton("CE", cols[1], rows[1], bw, bh, (s, e) => { _display = "0"; _isNewEntry = true; _isError = false; UpdateDisplay(); });
        AddButton("C", cols[2], rows[1], bw, bh, (s, e) => ClearAll());
        AddButton("±", cols[3], rows[1], bw, bh, (s, e) => SignFlip());
        AddButton("√", cols[4], rows[1], bw, bh, (s, e) => { ParseCurrent(); if (_current < 0) { SetError(); return; } _current = Math.Sqrt(_current); _display = FormatNumber(_current); _isNewEntry = true; UpdateDisplay(); });

        AddButton("7", cols[0], rows[2], bw, bh, (s, e) => EnterDigit('7'));
        AddButton("8", cols[1], rows[2], bw, bh, (s, e) => EnterDigit('8'));
        AddButton("9", cols[2], rows[2], bw, bh, (s, e) => EnterDigit('9'));
        AddButton("÷", cols[3], rows[2], bw, bh, (s, e) => SetOperator("/"));
        AddButton("%", cols[4], rows[2], bw, bh, (s, e) => ApplyPercent());

        AddButton("4", cols[0], rows[3], bw, bh, (s, e) => EnterDigit('4'));
        AddButton("5", cols[1], rows[3], bw, bh, (s, e) => EnterDigit('5'));
        AddButton("6", cols[2], rows[3], bw, bh, (s, e) => EnterDigit('6'));
        AddButton("×", cols[3], rows[3], bw, bh, (s, e) => SetOperator("*"));
        AddButton("1/x", cols[4], rows[3], bw, bh, (s, e) => { ParseCurrent(); if (_current == 0) { SetError(); return; } _current = 1.0 / _current; _display = FormatNumber(_current); _isNewEntry = true; UpdateDisplay(); });

        AddButton("1", cols[0], rows[4], bw, bh, (s, e) => EnterDigit('1'));
        AddButton("2", cols[1], rows[4], bw, bh, (s, e) => EnterDigit('2'));
        AddButton("3", cols[2], rows[4], bw, bh, (s, e) => EnterDigit('3'));
        AddButton("−", cols[3], rows[4], bw, bh, (s, e) => SetOperator("-"));
        AddButtonAccent("=", cols[4], rows[4], bw, bh + bh + 4, (s, e) => DoEquals());

        AddButton("0", cols[0], rows[5], bw * 2 + 4, bh, (s, e) => EnterDigit('0'));
        AddButton(".", cols[2], rows[5], bw, bh, (s, e) => EnterDecimal());
        AddButton("+", cols[3], rows[5], bw, bh, (s, e) => SetOperator("+"));
    }

    private void BuildActionRow() {
        int actionY = 314, actionH = 34;

        _btnInsert = MakeActionButton("Insert →", 8, actionY, 110, actionH, (s, e) => DoInsert());
        _btnInsert.BackColor = WarmAccent;
        _btnInsert.ForeColor = Color.White;
        _btnInsert.FlatAppearance.MouseOverBackColor = Color.FromArgb(0xB8, 0x8C, 0x5E);
        _btnInsert.FlatAppearance.MouseDownBackColor = Color.FromArgb(0x8A, 0x64, 0x3E);
        this.Controls.Add(_btnInsert);

        _btnCopy = MakeActionButton("Copy", 122, actionY, 60, actionH, (s, e) => DoCopy());
        this.Controls.Add(_btnCopy);

        _btnClose = MakeActionButton("Close", 186, actionY, 68, actionH, (s, e) => this.Hide());
        this.Controls.Add(_btnClose);
    }

    private Button AddButton(string text, int x, int y, int w, int h, EventHandler onClick) {
        Button b = new Button();
        b.Text = text;
        b.Location = new Point(x, y);
        b.Size = new Size(w, h);
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 1;
        b.FlatAppearance.BorderColor = WarmButtonBorder;
        b.FlatAppearance.MouseOverBackColor = WarmButtonHover;
        b.FlatAppearance.MouseDownBackColor = WarmButtonDown;
        b.BackColor = WarmButtonBg;
        b.ForeColor = WarmText;
        b.Font = new Font("Segoe UI", 10F);
        b.Cursor = Cursors.Hand;
        b.TabStop = false;
        b.Click += onClick;
        this.Controls.Add(b);
        return b;
    }

    private Button AddButtonAccent(string text, int x, int y, int w, int h, EventHandler onClick) {
        Button b = AddButton(text, x, y, w, h, onClick);
        b.BackColor = WarmAccent;
        b.ForeColor = Color.White;
        b.FlatAppearance.BorderColor = Color.FromArgb(0x8A, 0x64, 0x3E);
        b.FlatAppearance.MouseOverBackColor = Color.FromArgb(0xB8, 0x8C, 0x5E);
        b.FlatAppearance.MouseDownBackColor = Color.FromArgb(0x8A, 0x64, 0x3E);
        return b;
    }

    private Button MakeActionButton(string text, int x, int y, int w, int h, EventHandler onClick) {
        Button b = new Button();
        b.Text = text;
        b.Location = new Point(x, y);
        b.Size = new Size(w, h);
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 1;
        b.FlatAppearance.BorderColor = WarmButtonBorder;
        b.FlatAppearance.MouseOverBackColor = WarmButtonHover;
        b.FlatAppearance.MouseDownBackColor = WarmButtonDown;
        b.BackColor = WarmButtonBg;
        b.ForeColor = WarmText;
        b.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        b.Cursor = Cursors.Hand;
        b.TabStop = false;
        b.Click += onClick;
        return b;
    }

    // ---- Worksheet panel helpers ----

    private Panel AddPanelBase(string title) {
        Panel p = new Panel();
        p.Location = new Point(268, 8);
        p.Size = new Size(264, 346);
        p.BackColor = WarmCardBg;
        p.Visible = false;
        this.Controls.Add(p);

        Label lblTitle = new Label();
        lblTitle.Text = title;
        lblTitle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        lblTitle.ForeColor = WarmText;
        lblTitle.Location = new Point(10, 8);
        lblTitle.Size = new Size(244, 22);
        p.Controls.Add(lblTitle);

        Panel divider = new Panel();
        divider.BackColor = WarmButtonBorder;
        divider.Location = new Point(10, 36);
        divider.Size = new Size(244, 1);
        p.Controls.Add(divider);

        return p;
    }

    private TextBox AddPanelField(Panel parent, string label, int y) {
        Label lbl = new Label();
        lbl.Text = label + ":";
        lbl.Location = new Point(10, y + 3);
        lbl.Size = new Size(100, 18);
        lbl.Font = new Font("Segoe UI", 8.5F);
        lbl.ForeColor = WarmText;
        lbl.BackColor = Color.Transparent;
        parent.Controls.Add(lbl);

        TextBox tb = new TextBox();
        tb.Location = new Point(112, y);
        tb.Size = new Size(142, 23);
        tb.Font = new Font("Segoe UI", 9F);
        tb.BorderStyle = BorderStyle.FixedSingle;
        tb.BackColor = Color.White;
        tb.ForeColor = WarmText;
        parent.Controls.Add(tb);
        return tb;
    }

    private ComboBox AddPanelDropdown(Panel parent, string label, int y, string[] items, string selected) {
        Label lbl = new Label();
        lbl.Text = label + ":";
        lbl.Location = new Point(10, y + 3);
        lbl.Size = new Size(100, 18);
        lbl.Font = new Font("Segoe UI", 8.5F);
        lbl.ForeColor = WarmText;
        lbl.BackColor = Color.Transparent;
        parent.Controls.Add(lbl);

        ComboBox cb = new ComboBox();
        cb.Location = new Point(112, y);
        cb.Size = new Size(142, 23);
        cb.Font = new Font("Segoe UI", 9F);
        cb.DropDownStyle = ComboBoxStyle.DropDownList;
        cb.BackColor = Color.White;
        cb.ForeColor = WarmText;
        if (items != null) cb.Items.AddRange(items);
        if (selected != null) cb.SelectedItem = selected;
        else if (cb.Items.Count > 0) cb.SelectedIndex = 0;
        parent.Controls.Add(cb);
        return cb;
    }

    private Button AddPanelButton(Panel parent, string text, int x, int y, int w, int h, bool accent, EventHandler onClick) {
        Button b = new Button();
        b.Text = text;
        b.Location = new Point(x, y);
        b.Size = new Size(w, h);
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 1;
        b.Cursor = Cursors.Hand;
        b.TabStop = false;
        b.Click += onClick;
        if (accent) {
            b.FlatAppearance.BorderColor = Color.FromArgb(0x8A, 0x64, 0x3E);
            b.FlatAppearance.MouseOverBackColor = Color.FromArgb(0xB8, 0x8C, 0x5E);
            b.FlatAppearance.MouseDownBackColor = Color.FromArgb(0x8A, 0x64, 0x3E);
            b.BackColor = WarmAccent;
            b.ForeColor = Color.White;
            b.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        } else {
            b.FlatAppearance.BorderColor = WarmButtonBorder;
            b.FlatAppearance.MouseOverBackColor = WarmButtonHover;
            b.FlatAppearance.MouseDownBackColor = WarmButtonDown;
            b.BackColor = WarmButtonBg;
            b.ForeColor = WarmText;
            b.Font = new Font("Segoe UI", 9F);
        }
        parent.Controls.Add(b);
        return b;
    }

    private Label AddPanelStatus(Panel parent, int y) {
        Label lbl = new Label();
        lbl.Location = new Point(10, y);
        lbl.Size = new Size(244, 60);
        lbl.Font = new Font("Segoe UI", 8F, FontStyle.Italic);
        lbl.ForeColor = WarmMuted;
        lbl.BackColor = Color.Transparent;
        parent.Controls.Add(lbl);
        return lbl;
    }

    // ---- Mortgage panel ----

    private void BuildMortgagePanel() {
        _mortgagePanel = AddPanelBase("Mortgage Repayment");
        _mortPrincipal = AddPanelField(_mortgagePanel, "Principal", 48);
        _mortRate = AddPanelField(_mortgagePanel, "Rate (% per year)", 86);
        _mortTerm = AddPanelField(_mortgagePanel, "Term (years)", 124);
        _mortPayment = AddPanelField(_mortgagePanel, "Monthly payment", 162);

        AddPanelButton(_mortgagePanel, "Calculate", 10, 208, 120, 32, true, (s, e) => CalculateMortgage());
        AddPanelButton(_mortgagePanel, "Clear", 140, 208, 114, 32, false, (s, e) => ClearMortgageFields());

        _mortStatus = AddPanelStatus(_mortgagePanel, 250);
        _mortStatus.Text = "Fill any three fields — I'll solve the fourth.";
    }

    private void ClearMortgageFields() {
        _mortPrincipal.Text = "";
        _mortRate.Text = "";
        _mortTerm.Text = "";
        _mortPayment.Text = "";
        _mortStatus.Text = "Fill any three fields — I'll solve the fourth.";
    }

    private void CalculateMortgage() {
        string ps = _mortPrincipal.Text.Trim();
        string rs = _mortRate.Text.Trim();
        string ts = _mortTerm.Text.Trim();
        string ms = _mortPayment.Text.Trim();

        int filled = 0;
        if (ps.Length > 0) filled++;
        if (rs.Length > 0) filled++;
        if (ts.Length > 0) filled++;
        if (ms.Length > 0) filled++;

        if (filled < 3) { _mortStatus.Text = "Fill any three fields — I'll solve the fourth."; return; }

        double p = 0, r = 0, t = 0, m = 0;
        bool haveP = double.TryParse(ps, NumberStyles.Float, CultureInfo.InvariantCulture, out p);
        bool haveR = double.TryParse(rs, NumberStyles.Float, CultureInfo.InvariantCulture, out r);
        bool haveT = double.TryParse(ts, NumberStyles.Float, CultureInfo.InvariantCulture, out t);
        bool haveM = double.TryParse(ms, NumberStyles.Float, CultureInfo.InvariantCulture, out m);

        try {
            if (!haveP && haveR && haveT && haveM) {
                p = CalcPrincipal(m, r, t);
                _mortPrincipal.Text = p.ToString("0.00", CultureInfo.InvariantCulture);
                _mortStatus.Text = "Solved: Principal = " + p.ToString("N2", CultureInfo.InvariantCulture);
            } else if (haveP && !haveR && haveT && haveM) {
                r = CalcRate(p, t, m);
                if (double.IsNaN(r)) { _mortStatus.Text = "Could not solve for rate — check your values."; return; }
                _mortRate.Text = r.ToString("0.####", CultureInfo.InvariantCulture);
                _mortStatus.Text = "Solved: Rate = " + r.ToString("0.####", CultureInfo.InvariantCulture) + " % per year";
            } else if (haveP && haveR && !haveT && haveM) {
                t = CalcTerm(p, r, m);
                if (double.IsNaN(t)) { _mortStatus.Text = "Payment too small — the loan would never pay off."; return; }
                _mortTerm.Text = t.ToString("0.####", CultureInfo.InvariantCulture);
                _mortStatus.Text = "Solved: Term = " + t.ToString("0.####", CultureInfo.InvariantCulture) + " years";
            } else if (haveP && haveR && haveT && !haveM) {
                m = CalcPayment(p, r, t);
                _mortPayment.Text = m.ToString("0.00", CultureInfo.InvariantCulture);
                _mortStatus.Text = "Solved: Monthly payment = " + m.ToString("N2", CultureInfo.InvariantCulture);
            } else {
                double expectedPayment = CalcPayment(p, r, t);
                double diff = Math.Abs(expectedPayment - m);
                if (diff < 0.5) _mortStatus.Text = "All four fields are consistent. ✓";
                else _mortStatus.Text = "Values don't match. Expected monthly payment: " + expectedPayment.ToString("N2", CultureInfo.InvariantCulture);
            }
        } catch (Exception ex) {
            _mortStatus.Text = "Calculation error: " + ex.Message;
        }
    }

    private double CalcPayment(double principal, double annualRatePct, double years) {
        double months = years * 12.0;
        if (months <= 0 || principal <= 0) return double.NaN;
        if (annualRatePct == 0) return principal / months;
        double i = annualRatePct / 100.0 / 12.0;
        double factor = Math.Pow(1 + i, months);
        return principal * i * factor / (factor - 1);
    }

    private double CalcPrincipal(double payment, double annualRatePct, double years) {
        double months = years * 12.0;
        if (months <= 0 || payment <= 0) return double.NaN;
        if (annualRatePct == 0) return payment * months;
        double i = annualRatePct / 100.0 / 12.0;
        double factor = Math.Pow(1 + i, months);
        return payment * (factor - 1) / (i * factor);
    }

    private double CalcTerm(double principal, double annualRatePct, double payment) {
        if (principal <= 0 || payment <= 0) return double.NaN;
        if (annualRatePct == 0) return principal / payment / 12.0;
        double i = annualRatePct / 100.0 / 12.0;
        double minPayment = principal * i;
        if (payment <= minPayment) return double.NaN;
        return Math.Log(payment / (payment - minPayment)) / Math.Log(1 + i) / 12.0;
    }

    private double CalcRate(double principal, double years, double payment) {
        if (principal <= 0 || years <= 0 || payment <= 0) return double.NaN;
        double low = 0.0001, high = 100.0;
        double lowPMT = CalcPayment(principal, low, years);
        double highPMT = CalcPayment(principal, high, years);
        if (payment < lowPMT || payment > highPMT * 1.5) return double.NaN;
        for (int i = 0; i < 200; i++) {
            double mid = (low + high) / 2.0;
            double midPMT = CalcPayment(principal, mid, years);
            if (Math.Abs(midPMT - payment) < 0.0001) return mid;
            if (midPMT < payment) low = mid;
            else high = mid;
        }
        return (low + high) / 2.0;
    }

    // ---- Fixed deposit panel ----

    private void BuildFDPanel() {
        _fdPanel = AddPanelBase("Fixed Deposit");
        _fdPrincipal = AddPanelField(_fdPanel, "Principal", 48);
        _fdRate = AddPanelField(_fdPanel, "Rate (% per year)", 86);
        _fdTerm = AddPanelField(_fdPanel, "Term (years)", 124);
        _fdCompounding = AddPanelDropdown(_fdPanel, "Compounding", 162, CompoundingOptions, "Annually");
        _fdMaturity = AddPanelField(_fdPanel, "Maturity", 200);

        AddPanelButton(_fdPanel, "Calculate", 10, 246, 120, 32, true, (s, e) => CalculateFD());
        AddPanelButton(_fdPanel, "Clear", 140, 246, 114, 32, false, (s, e) => ClearFDFields());

        _fdStatus = AddPanelStatus(_fdPanel, 288);
        _fdStatus.Text = "Fill any three of the four — I'll solve the fourth.";
    }

    private void ClearFDFields() {
        _fdPrincipal.Text = "";
        _fdRate.Text = "";
        _fdTerm.Text = "";
        _fdMaturity.Text = "";
        _fdStatus.Text = "Fill any three of the four — I'll solve the fourth.";
    }

    private void CalculateFD() {
        string ps = _fdPrincipal.Text.Trim();
        string rs = _fdRate.Text.Trim();
        string ts = _fdTerm.Text.Trim();
        string as_ = _fdMaturity.Text.Trim();

        int filled = 0;
        if (ps.Length > 0) filled++;
        if (rs.Length > 0) filled++;
        if (ts.Length > 0) filled++;
        if (as_.Length > 0) filled++;

        if (filled < 3) { _fdStatus.Text = "Fill any three of the four — I'll solve the fourth."; return; }

        double p = 0, r = 0, t = 0, a = 0;
        bool haveP = double.TryParse(ps, NumberStyles.Float, CultureInfo.InvariantCulture, out p);
        bool haveR = double.TryParse(rs, NumberStyles.Float, CultureInfo.InvariantCulture, out r);
        bool haveT = double.TryParse(ts, NumberStyles.Float, CultureInfo.InvariantCulture, out t);
        bool haveA = double.TryParse(as_, NumberStyles.Float, CultureInfo.InvariantCulture, out a);
        int n = CompoundingPeriods(_fdCompounding.SelectedItem as string);
        string compound = (_fdCompounding.SelectedItem as string) ?? "Annually";

        try {
            if (!haveP && haveR && haveT && haveA) {
                p = a / Math.Pow(1 + r / 100.0 / n, n * t);
                _fdPrincipal.Text = p.ToString("0.00", CultureInfo.InvariantCulture);
                _fdStatus.Text = "Solved: Principal = " + p.ToString("N2", CultureInfo.InvariantCulture);
            } else if (haveP && !haveR && haveT && haveA) {
                r = n * (Math.Pow(a / p, 1.0 / (n * t)) - 1) * 100.0;
                _fdRate.Text = r.ToString("0.####", CultureInfo.InvariantCulture);
                _fdStatus.Text = "Solved: Rate = " + r.ToString("0.####", CultureInfo.InvariantCulture) + " % per year";
            } else if (haveP && haveR && !haveT && haveA) {
                double dailyBase = 1 + r / 100.0 / n;
                if (dailyBase <= 1) { _fdStatus.Text = "Rate too small to solve for term."; return; }
                t = Math.Log(a / p) / (n * Math.Log(dailyBase));
                _fdTerm.Text = t.ToString("0.####", CultureInfo.InvariantCulture);
                _fdStatus.Text = "Solved: Term = " + t.ToString("0.####", CultureInfo.InvariantCulture) + " years";
            } else if (haveP && haveR && haveT && !haveA) {
                a = p * Math.Pow(1 + r / 100.0 / n, n * t);
                _fdMaturity.Text = a.ToString("0.00", CultureInfo.InvariantCulture);
                _fdStatus.Text = "Solved: Maturity = " + a.ToString("N2", CultureInfo.InvariantCulture) + " (" + compound + " compounding)";
            } else {
                double expected = p * Math.Pow(1 + r / 100.0 / n, n * t);
                double diff = Math.Abs(expected - a);
                if (diff < 0.05) _fdStatus.Text = "All four fields are consistent. ✓";
                else _fdStatus.Text = "Values don't match. Expected maturity: " + expected.ToString("N2", CultureInfo.InvariantCulture);
            }
        } catch (Exception ex) {
            _fdStatus.Text = "Calculation error: " + ex.Message;
        }
    }

    private int CompoundingPeriods(string choice) {
        if (choice == null) return 1;
        if (choice == "Daily") return 365;
        if (choice == "Monthly") return 12;
        if (choice == "Quarterly") return 4;
        if (choice == "Semi-annually") return 2;
        return 1;
    }

    // ---- Recurring saver panel ----
    // Now includes an initial Principal (lump sum you already have)
    // alongside the monthly deposit. 5 numeric fields total.

    private void BuildRSPanel() {
        _rsPanel = AddPanelBase("Recurring Saver");
        _rsPrincipal = AddPanelField(_rsPanel, "Initial principal", 44);
        _rsDeposit = AddPanelField(_rsPanel, "Monthly deposit", 74);
        _rsRate = AddPanelField(_rsPanel, "Rate (% per year)", 104);
        _rsTerm = AddPanelField(_rsPanel, "Term (years)", 134);
        _rsCompounding = AddPanelDropdown(_rsPanel, "Compounding", 164, CompoundingOptions, "Daily");
        _rsMaturity = AddPanelField(_rsPanel, "Maturity", 194);

        AddPanelButton(_rsPanel, "Calculate", 10, 232, 120, 32, true, (s, e) => CalculateRS());
        AddPanelButton(_rsPanel, "Clear", 140, 232, 114, 32, false, (s, e) => ClearRSFields());

        _rsStatus = AddPanelStatus(_rsPanel, 274);
        _rsStatus.Text = "Fill any four of the five — I'll solve the fifth.";
    }

    private void ClearRSFields() {
        _rsPrincipal.Text = "";
        _rsDeposit.Text = "";
        _rsRate.Text = "";
        _rsTerm.Text = "";
        _rsMaturity.Text = "";
        _rsStatus.Text = "Fill any four of the five — I'll solve the fifth.";
    }

    private void CalculateRS() {
        string ps = _rsPrincipal.Text.Trim();
        string ds = _rsDeposit.Text.Trim();
        string rs = _rsRate.Text.Trim();
        string ts = _rsTerm.Text.Trim();
        string as_ = _rsMaturity.Text.Trim();

        int filled = 0;
        if (ps.Length > 0) filled++;
        if (ds.Length > 0) filled++;
        if (rs.Length > 0) filled++;
        if (ts.Length > 0) filled++;
        if (as_.Length > 0) filled++;

        if (filled < 4) { _rsStatus.Text = "Fill any four of the five — I'll solve the fifth."; return; }

        double p = 0, d = 0, r = 0, t = 0, a = 0;
        bool haveP = double.TryParse(ps, NumberStyles.Float, CultureInfo.InvariantCulture, out p);
        bool haveD = double.TryParse(ds, NumberStyles.Float, CultureInfo.InvariantCulture, out d);
        bool haveR = double.TryParse(rs, NumberStyles.Float, CultureInfo.InvariantCulture, out r);
        bool haveT = double.TryParse(ts, NumberStyles.Float, CultureInfo.InvariantCulture, out t);
        bool haveA = double.TryParse(as_, NumberStyles.Float, CultureInfo.InvariantCulture, out a);
        int n = CompoundingPeriods(_rsCompounding.SelectedItem as string);
        string compound = (_rsCompounding.SelectedItem as string) ?? "Daily";

        try {
            if (!haveP && haveD && haveR && haveT && haveA) {
                p = RSMaturityToPrincipal(a, d, r, t, n);
                if (double.IsNaN(p)) { _rsStatus.Text = "Could not solve for principal — check your values."; return; }
                _rsPrincipal.Text = p.ToString("0.00", CultureInfo.InvariantCulture);
                _rsStatus.Text = "Solved: Initial principal = " + p.ToString("N2", CultureInfo.InvariantCulture);
            } else if (haveP && !haveD && haveR && haveT && haveA) {
                d = RSMaturityToDeposit(a, p, r, t, n);
                if (double.IsNaN(d)) { _rsStatus.Text = "Could not solve for deposit — check your values."; return; }
                _rsDeposit.Text = d.ToString("0.00", CultureInfo.InvariantCulture);
                _rsStatus.Text = "Solved: Monthly deposit = " + d.ToString("N2", CultureInfo.InvariantCulture);
            } else if (haveP && haveD && !haveR && haveT && haveA) {
                r = RSRateBisection(p, d, t, a, n);
                if (double.IsNaN(r)) { _rsStatus.Text = "Could not solve for rate — check your values."; return; }
                _rsRate.Text = r.ToString("0.####", CultureInfo.InvariantCulture);
                _rsStatus.Text = "Solved: Rate = " + r.ToString("0.####", CultureInfo.InvariantCulture) + " % per year";
            } else if (haveP && haveD && haveR && !haveT && haveA) {
                t = RSTermBisection(p, d, r, a, n);
                if (double.IsNaN(t)) { _rsStatus.Text = "Could not solve for term — check your values."; return; }
                _rsTerm.Text = t.ToString("0.####", CultureInfo.InvariantCulture);
                _rsStatus.Text = "Solved: Term = " + t.ToString("0.####", CultureInfo.InvariantCulture) + " years";
            } else if (haveP && haveD && haveR && haveT && !haveA) {
                a = RSMaturity(p, d, r, t, n);
                _rsMaturity.Text = a.ToString("0.00", CultureInfo.InvariantCulture);
                _rsStatus.Text = "Solved: Maturity = " + a.ToString("N2", CultureInfo.InvariantCulture) + " (" + compound + " compounding)";
            } else {
                double expected = RSMaturity(p, d, r, t, n);
                double diff = Math.Abs(expected - a);
                if (diff < 0.05) _rsStatus.Text = "All five fields are consistent. ✓";
                else _rsStatus.Text = "Values don't match. Expected maturity: " + expected.ToString("N2", CultureInfo.InvariantCulture);
            }
        } catch (Exception ex) {
            _rsStatus.Text = "Calculation error: " + ex.Message;
        }
    }

    // RS model: initial principal P grows at i per period, PLUS monthly deposits
    // (converted to per-period deposits) accumulate. Standard compound-annuity mix.
    private double RSMaturity(double principal, double monthlyDeposit, double annualRatePct, double years, int n) {
        if (years <= 0 || n <= 0) return double.NaN;
        double i = annualRatePct / 100.0 / n;
        double totalPeriods = years * n;
        double pmtPerPeriod = monthlyDeposit * 12.0 / n;
        if (i == 0) return principal + pmtPerPeriod * totalPeriods;
        double growth = Math.Pow(1 + i, totalPeriods);
        return principal * growth + pmtPerPeriod * (growth - 1) / i;
    }

    private double RSMaturityToPrincipal(double maturity, double monthlyDeposit, double annualRatePct, double years, int n) {
        if (years <= 0 || n <= 0) return double.NaN;
        double i = annualRatePct / 100.0 / n;
        double totalPeriods = years * n;
        double pmtPerPeriod = monthlyDeposit * 12.0 / n;
        if (i == 0) return maturity - pmtPerPeriod * totalPeriods;
        double growth = Math.Pow(1 + i, totalPeriods);
        return (maturity - pmtPerPeriod * (growth - 1) / i) / growth;
    }

    private double RSMaturityToDeposit(double maturity, double principal, double annualRatePct, double years, int n) {
        if (years <= 0 || n <= 0) return double.NaN;
        double i = annualRatePct / 100.0 / n;
        double totalPeriods = years * n;
        if (i == 0) {
            double total = maturity - principal;
            return total / totalPeriods * n / 12.0;
        }
        double growth = Math.Pow(1 + i, totalPeriods);
        double pmtPerPeriod = (maturity - principal * growth) * i / (growth - 1);
        return pmtPerPeriod * n / 12.0;
    }

    private double RSRateBisection(double principal, double monthlyDeposit, double years, double targetMaturity, int n) {
        if (years <= 0 || targetMaturity <= 0) return double.NaN;
        double low = 0.0, high = 100.0;
        double lowVal = RSMaturity(principal, monthlyDeposit, low, years, n);
        double highVal = RSMaturity(principal, monthlyDeposit, high, years, n);
        if (targetMaturity < lowVal * 0.99 || targetMaturity > highVal * 1.5) return double.NaN;
        for (int iter = 0; iter < 200; iter++) {
            double mid = (low + high) / 2.0;
            double midVal = RSMaturity(principal, monthlyDeposit, mid, years, n);
            if (Math.Abs(midVal - targetMaturity) < 0.01) return mid;
            if (midVal < targetMaturity) low = mid; else high = mid;
        }
        return (low + high) / 2.0;
    }

    private double RSTermBisection(double principal, double monthlyDeposit, double annualRatePct, double targetMaturity, int n) {
        if (targetMaturity <= 0) return double.NaN;
        double low = 0.01, high = 200.0;
        double lowVal = RSMaturity(principal, monthlyDeposit, annualRatePct, low, n);
        double highVal = RSMaturity(principal, monthlyDeposit, annualRatePct, high, n);
        if (targetMaturity < lowVal || targetMaturity > highVal) return double.NaN;
        for (int iter = 0; iter < 200; iter++) {
            double mid = (low + high) / 2.0;
            double midVal = RSMaturity(principal, monthlyDeposit, annualRatePct, mid, n);
            if (Math.Abs(midVal - targetMaturity) < 0.01) return mid;
            if (midVal < targetMaturity) low = mid; else high = mid;
        }
        return (low + high) / 2.0;
    }

    // ---- Unit conversion panel ----

    private void BuildUnitPanel() {
        _unitPanel = AddPanelBase("Unit Conversion");

        _ucCategory = AddPanelDropdown(_unitPanel, "Category", 48, null, null);
        foreach (UnitCat c in UnitCategories) _ucCategory.Items.Add(c.Name);
        _ucCategory.SelectedIndex = 0;
        _ucCategory.SelectedIndexChanged += (s, e) => RefreshUnitDropdowns();

        _ucFrom = AddPanelDropdown(_unitPanel, "From", 86, null, null);
        _ucFrom.SelectedIndexChanged += (s, e) => DoUnitConvert();

        _ucFromValue = AddPanelField(_unitPanel, "Value", 124);
        _ucFromValue.TextChanged += (s, e) => DoUnitConvert();

        _ucTo = AddPanelDropdown(_unitPanel, "To", 162, null, null);
        _ucTo.SelectedIndexChanged += (s, e) => DoUnitConvert();

        _ucToValue = AddPanelField(_unitPanel, "Result", 200);
        _ucToValue.ReadOnly = true;
        _ucToValue.BackColor = WarmButtonBg;

        AddPanelButton(_unitPanel, "Convert →", 10, 246, 120, 32, true, (s, e) => DoUnitConvert());
        AddPanelButton(_unitPanel, "Swap", 140, 246, 114, 32, false, (s, e) => SwapUnits());

        _ucStatus = AddPanelStatus(_unitPanel, 288);
        _ucStatus.Text = "Type a value and pick units.";

        RefreshUnitDropdowns();
    }

    private void RefreshUnitDropdowns() {
        int catIdx = _ucCategory.SelectedIndex;
        if (catIdx < 0 || catIdx >= UnitCategories.Length) return;
        UnitCat cat = UnitCategories[catIdx];

        _ucFrom.Items.Clear();
        _ucTo.Items.Clear();
        foreach (string u in cat.Units) { _ucFrom.Items.Add(u); _ucTo.Items.Add(u); }
        if (_ucFrom.Items.Count > 0) _ucFrom.SelectedIndex = 0;
        if (_ucTo.Items.Count > 1) _ucTo.SelectedIndex = 1;
        DoUnitConvert();
    }

    private void SwapUnits() {
        int fromIdx = _ucFrom.SelectedIndex;
        int toIdx = _ucTo.SelectedIndex;
        if (fromIdx < 0 || toIdx < 0) return;
        _ucFrom.SelectedIndex = toIdx;
        _ucTo.SelectedIndex = fromIdx;
        DoUnitConvert();
    }

    private void DoUnitConvert() {
        if (_ucCategory.SelectedIndex < 0) return;
        UnitCat cat = UnitCategories[_ucCategory.SelectedIndex];
        if (_ucFrom.SelectedIndex < 0 || _ucTo.SelectedIndex < 0) return;

        string raw = _ucFromValue.Text.Trim();
        if (raw.Length == 0) { _ucToValue.Text = ""; _ucStatus.Text = "Type a value and pick units."; return; }

        double val;
        if (!double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out val)) {
            _ucToValue.Text = "";
            _ucStatus.Text = "Value must be a number.";
            return;
        }

        double result;
        if (cat.IsTemp) {
            double c = TempToCelsius(val, _ucFrom.SelectedIndex);
            result = CelsiusToTemp(c, _ucTo.SelectedIndex);
        } else {
            double baseVal = val * cat.Factors[_ucFrom.SelectedIndex];
            result = baseVal / cat.Factors[_ucTo.SelectedIndex];
        }

        _ucToValue.Text = result.ToString("0.############", CultureInfo.InvariantCulture);
        _ucStatus.Text = val.ToString("0.######", CultureInfo.InvariantCulture) + " " + cat.Units[_ucFrom.SelectedIndex]
            + " = " + result.ToString("0.######", CultureInfo.InvariantCulture) + " " + cat.Units[_ucTo.SelectedIndex];
    }

    private double TempToCelsius(double v, int idx) {
        if (idx == 0) return v;
        if (idx == 1) return (v - 32.0) * 5.0 / 9.0;
        if (idx == 2) return v - 273.15;
        return v;
    }

    private double CelsiusToTemp(double c, int idx) {
        if (idx == 0) return c;
        if (idx == 1) return c * 9.0 / 5.0 + 32.0;
        if (idx == 2) return c + 273.15;
        return c;
    }

    // ---- Date calculation panel ----

    private void BuildDatePanel() {
        _datePanel = AddPanelBase("Date Calculation");

        _dcMode = AddPanelDropdown(_datePanel, "Mode", 48, new string[] { "Difference", "Add / Subtract" }, "Difference");
        _dcMode.SelectedIndexChanged += (s, e) => RefreshDateMode();

        _dcFromLbl = new Label();
        _dcFromLbl.Text = "From:";
        _dcFromLbl.Location = new Point(10, 89);
        _dcFromLbl.Size = new Size(100, 18);
        _dcFromLbl.Font = new Font("Segoe UI", 8.5F);
        _dcFromLbl.ForeColor = WarmText;
        _dcFromLbl.BackColor = Color.Transparent;
        _datePanel.Controls.Add(_dcFromLbl);

        _dcFrom = new DateTimePicker();
        _dcFrom.Location = new Point(112, 86);
        _dcFrom.Size = new Size(142, 23);
        _dcFrom.Font = new Font("Segoe UI", 9F);
        _dcFrom.Format = DateTimePickerFormat.Short;
        _datePanel.Controls.Add(_dcFrom);

        _dcToLbl = new Label();
        _dcToLbl.Text = "To:";
        _dcToLbl.Location = new Point(10, 127);
        _dcToLbl.Size = new Size(100, 18);
        _dcToLbl.Font = new Font("Segoe UI", 8.5F);
        _dcToLbl.ForeColor = WarmText;
        _dcToLbl.BackColor = Color.Transparent;
        _datePanel.Controls.Add(_dcToLbl);

        _dcTo = new DateTimePicker();
        _dcTo.Location = new Point(112, 124);
        _dcTo.Size = new Size(142, 23);
        _dcTo.Font = new Font("Segoe UI", 9F);
        _dcTo.Format = DateTimePickerFormat.Short;
        _dcTo.Value = DateTime.Today.AddDays(30);
        _datePanel.Controls.Add(_dcTo);

        _dcStartLbl = new Label();
        _dcStartLbl.Text = "Start:";
        _dcStartLbl.Location = new Point(10, 89);
        _dcStartLbl.Size = new Size(100, 18);
        _dcStartLbl.Font = new Font("Segoe UI", 8.5F);
        _dcStartLbl.ForeColor = WarmText;
        _dcStartLbl.BackColor = Color.Transparent;
        _datePanel.Controls.Add(_dcStartLbl);

        _dcStart = new DateTimePicker();
        _dcStart.Location = new Point(112, 86);
        _dcStart.Size = new Size(142, 23);
        _dcStart.Font = new Font("Segoe UI", 9F);
        _dcStart.Format = DateTimePickerFormat.Short;
        _datePanel.Controls.Add(_dcStart);

        _dcAmountLbl = new Label();
        _dcAmountLbl.Text = "Amount:";
        _dcAmountLbl.Location = new Point(10, 127);
        _dcAmountLbl.Size = new Size(100, 18);
        _dcAmountLbl.Font = new Font("Segoe UI", 8.5F);
        _dcAmountLbl.ForeColor = WarmText;
        _dcAmountLbl.BackColor = Color.Transparent;
        _datePanel.Controls.Add(_dcAmountLbl);

        _dcAmount = new TextBox();
        _dcAmount.Location = new Point(112, 124);
        _dcAmount.Size = new Size(142, 23);
        _dcAmount.Font = new Font("Segoe UI", 9F);
        _dcAmount.BorderStyle = BorderStyle.FixedSingle;
        _dcAmount.Text = "30";
        _datePanel.Controls.Add(_dcAmount);

        _dcUnitLbl = new Label();
        _dcUnitLbl.Text = "Unit:";
        _dcUnitLbl.Location = new Point(10, 165);
        _dcUnitLbl.Size = new Size(100, 18);
        _dcUnitLbl.Font = new Font("Segoe UI", 8.5F);
        _dcUnitLbl.ForeColor = WarmText;
        _dcUnitLbl.BackColor = Color.Transparent;
        _datePanel.Controls.Add(_dcUnitLbl);

        _dcUnit = new ComboBox();
        _dcUnit.Location = new Point(112, 162);
        _dcUnit.Size = new Size(142, 23);
        _dcUnit.Font = new Font("Segoe UI", 9F);
        _dcUnit.DropDownStyle = ComboBoxStyle.DropDownList;
        _dcUnit.BackColor = Color.White;
        _dcUnit.Items.AddRange(new object[] { "Days", "Weeks", "Months", "Years" });
        _dcUnit.SelectedIndex = 0;
        _datePanel.Controls.Add(_dcUnit);

        _dcDirectionLbl = new Label();
        _dcDirectionLbl.Text = "Direction:";
        _dcDirectionLbl.Location = new Point(10, 203);
        _dcDirectionLbl.Size = new Size(100, 18);
        _dcDirectionLbl.Font = new Font("Segoe UI", 8.5F);
        _dcDirectionLbl.ForeColor = WarmText;
        _dcDirectionLbl.BackColor = Color.Transparent;
        _datePanel.Controls.Add(_dcDirectionLbl);

        _dcDirection = new ComboBox();
        _dcDirection.Location = new Point(112, 200);
        _dcDirection.Size = new Size(142, 23);
        _dcDirection.Font = new Font("Segoe UI", 9F);
        _dcDirection.DropDownStyle = ComboBoxStyle.DropDownList;
        _dcDirection.BackColor = Color.White;
        _dcDirection.Items.AddRange(new object[] { "Add", "Subtract" });
        _dcDirection.SelectedIndex = 0;
        _datePanel.Controls.Add(_dcDirection);

        _dcCalcBtn = AddPanelButton(_datePanel, "Calculate", 10, 246, 244, 32, true, (s, e) => DoDateCalc());

        _dcStatus = AddPanelStatus(_datePanel, 288);

        RefreshDateMode();
    }

    private void RefreshDateMode() {
        bool isDiff = _dcMode.SelectedIndex == 0;

        _dcFromLbl.Visible = isDiff;
        _dcFrom.Visible = isDiff;
        _dcToLbl.Visible = isDiff;
        _dcTo.Visible = isDiff;

        _dcStartLbl.Visible = !isDiff;
        _dcStart.Visible = !isDiff;
        _dcAmountLbl.Visible = !isDiff;
        _dcAmount.Visible = !isDiff;
        _dcUnitLbl.Visible = !isDiff;
        _dcUnit.Visible = !isDiff;
        _dcDirectionLbl.Visible = !isDiff;
        _dcDirection.Visible = !isDiff;

        _dcStatus.Text = isDiff ? "Pick two dates, hit Calculate." : "Pick a start date and an amount, hit Calculate.";
    }

    private void DoDateCalc() {
        if (_dcMode.SelectedIndex == 0) {
            DateTime from = _dcFrom.Value.Date;
            DateTime to = _dcTo.Value.Date;
            if (to < from) { DateTime tmp = from; from = to; to = tmp; }

            int totalDays = (int)(to - from).TotalDays;
            int years = 0, months = 0;
            DateTime cursor = from;
            while (cursor.AddYears(1) <= to) { years++; cursor = cursor.AddYears(1); }
            while (cursor.AddMonths(1) <= to) { months++; cursor = cursor.AddMonths(1); }
            int days = (int)(to - cursor).TotalDays;

            string readable = "";
            if (years > 0) readable += years + (years == 1 ? " year" : " years");
            if (months > 0) { if (readable.Length > 0) readable += ", "; readable += months + (months == 1 ? " month" : " months"); }
            if (days > 0) { if (readable.Length > 0) readable += ", "; readable += days + (days == 1 ? " day" : " days"); }
            if (readable.Length == 0) readable = "0 days";

            _dcStatus.Text = "Difference: " + readable + "\n\nTotal: " + totalDays + (totalDays == 1 ? " day" : " days");
        } else {
            DateTime start = _dcStart.Value.Date;
            double amtD;
            if (!double.TryParse(_dcAmount.Text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out amtD)) {
                _dcStatus.Text = "Amount must be a number.";
                return;
            }
            int amt = (int)Math.Round(amtD);
            if (_dcDirection.SelectedIndex == 1) amt = -amt;

            DateTime end = start;
            string unit = _dcUnit.SelectedItem as string;
            if (unit == "Days") end = start.AddDays(amt);
            else if (unit == "Weeks") end = start.AddDays(amt * 7);
            else if (unit == "Months") end = end.AddMonths(amt);
            else if (unit == "Years") end = start.AddYears(amt);
            else end = start.AddDays(amt);

            _dcStatus.Text = "End date: " + end.ToString("yyyy-MM-dd") + "\n\n(" + end.ToString("dddd, MMMM d, yyyy") + ")";
        }
    }

    // ---- Worksheet visibility management ----

    private void ShowWorksheetPanel(Panel panel) {
        if (_activeWorksheet == panel) {
            FoldAllPanels();
            return;
        }
        if (_leftPanelExpanded) CollapseLeftPanel();
        if (_activeWorksheet != null) _activeWorksheet.Visible = false;
        _activeWorksheet = panel;
        if (panel != null) panel.Visible = true;
        this.ClientSize = new Size(CLIENT_W_OPEN, CLIENT_H);
        UpdateWorksheetMenuChecks();
        UpdateDisplay();
    }

    private void FoldAllPanels() {
        if (_activeWorksheet != null) _activeWorksheet.Visible = false;
        _activeWorksheet = null;
        if (_leftPanelExpanded) CollapseLeftPanel();
        this.ClientSize = new Size(CLIENT_W_CLOSED, CLIENT_H);
        UpdateWorksheetMenuChecks();
        UpdateDisplay();
    }

    private void UpdateWorksheetMenuChecks() {
        if (_mnuMortgage != null) _mnuMortgage.Checked = _activeWorksheet == _mortgagePanel;
        if (_mnuFD != null) _mnuFD.Checked = _activeWorksheet == _fdPanel;
        if (_mnuRS != null) _mnuRS.Checked = _activeWorksheet == _rsPanel;
        if (_mnuUnit != null) _mnuUnit.Checked = _activeWorksheet == _unitPanel;
        if (_mnuDate != null) _mnuDate.Checked = _activeWorksheet == _datePanel;
    }

    // ---- Calculator logic ----

    private void EnterDigit(char digit) {
        if (_isError) ClearAll();
        if (_isNewEntry) {
            _display = digit.ToString();
            _isNewEntry = false;
        } else {
            if (_display == "0") _display = digit.ToString();
            else if (_display == "-0") _display = "-" + digit.ToString();
            else {
                string raw = _display.Replace(",", "");
                if (raw.Length < 15) _display += digit.ToString();
                else return;
            }
        }
        UpdateDisplay();
    }

    private void EnterDecimal() {
        if (_isError) ClearAll();
        if (_isNewEntry) { _display = "0."; _isNewEntry = false; }
        else {
            string raw = _display.Replace(",", "");
            if (!raw.Contains(".")) _display += ".";
        }
        UpdateDisplay();
    }

    private void Backspace() {
        if (_isError || _isNewEntry) return;
        string raw = _display.Replace(",", "");
        if (raw.Length <= 1 || (raw.Length == 2 && raw.StartsWith("-"))) { _display = "0"; _isNewEntry = true; }
        else _display = raw.Substring(0, raw.Length - 1);
        UpdateDisplay();
    }

    private void SignFlip() {
        if (_isError) return;
        ParseCurrent();
        _current = -_current;
        _display = FormatNumber(_current);
        UpdateDisplay();
    }

    private void ParseCurrent() {
        try {
            string raw = _display.Replace(",", "");
            _current = double.Parse(raw, CultureInfo.InvariantCulture);
        } catch { _current = 0; }
    }

    private void SetOperator(string op) {
        if (_isError) return;
        ParseCurrent();
        string opSymbol = SymbolFor(op);

        if (_pendingOp == "" && !_isNewEntry) {
            _expressionChain = FormatNumber(_current) + " " + opSymbol + " ";
        } else if (_pendingOp != "" && !_isNewEntry) {
            _expressionChain += FormatNumber(_current) + " " + opSymbol + " ";
            double result = ApplyOp(_operand, _pendingOp, _current);
            if (double.IsNaN(result) || double.IsInfinity(result)) { SetError(); return; }
            _current = result;
            _display = FormatNumber(_current);
        } else if (_pendingOp != "" && _isNewEntry) {
            string trimmed = _expressionChain.TrimEnd();
            int lastSpace = trimmed.LastIndexOf(' ');
            if (lastSpace >= 0) _expressionChain = trimmed.Substring(0, lastSpace) + " " + opSymbol + " ";
            else _expressionChain = opSymbol + " ";
        }

        _operand = _current;
        _pendingOp = op;
        _isNewEntry = true;
        UpdateDisplay();
    }

    private string SymbolFor(string op) {
        if (op == "*") return "×";
        if (op == "/") return "÷";
        return op;
    }

    private double ApplyOp(double left, string op, double right) {
        switch (op) {
            case "+": return left + right;
            case "-": return left - right;
            case "*": return left * right;
            case "/": return right == 0 ? double.NaN : left / right;
        }
        return right;
    }

    private void DoEquals() {
        if (_isError) return;
        ParseCurrent();

        if (_pendingOp != "") {
            double result = ApplyOp(_operand, _pendingOp, _current);
            if (double.IsNaN(result) || double.IsInfinity(result)) { SetError(); return; }
            _lastOp = _pendingOp;
            _lastOpValue = _current;
            _current = result;
            _display = FormatNumber(_current);
            _pendingOp = "";
            _isNewEntry = true;
        } else if (_lastOp != "") {
            double result = ApplyOp(_current, _lastOp, _lastOpValue);
            if (double.IsNaN(result) || double.IsInfinity(result)) { SetError(); return; }
            _current = result;
            _display = FormatNumber(_current);
            _isNewEntry = true;
        }
        _expressionChain = "";
        UpdateDisplay();
    }

    private void ApplyPercent() {
        if (_isError) return;
        ParseCurrent();
        if (_pendingOp == "+" || _pendingOp == "-") _current = _operand * _current / 100.0;
        else _current = _current / 100.0;
        _display = FormatNumber(_current);
        _isNewEntry = true;
        UpdateDisplay();
    }

    private void ClearAll() {
        _display = "0";
        _current = 0;
        _operand = 0;
        _pendingOp = "";
        _lastOp = "";
        _lastOpValue = 0;
        _isNewEntry = true;
        _isError = false;
        _expressionChain = "";
        UpdateDisplay();
    }

    private void SetError() {
        _display = "Error";
        _isError = true;
        _isNewEntry = true;
        _pendingOp = "";
        UpdateDisplay();
    }

    private void UpdateDisplay() {
        if (_isError) {
            _displayLabel.Text = "Error";
            _expressionLabel.Text = "";
            if (_leftPanelExpanded) CollapseLeftPanel();
            return;
        }
        _displayLabel.Text = _display;

        if (!string.IsNullOrEmpty(_expressionChain)) {
            string expr = _expressionChain;
            if (!_isNewEntry && _pendingOp != "") expr += _display;
            UpdateExpressionDisplay(expr);
        } else {
            _expressionLabel.Text = "";
            if (_leftPanelExpanded) CollapseLeftPanel();
        }
    }

    private void UpdateExpressionDisplay(string fullExpr) {
        if (string.IsNullOrEmpty(fullExpr)) {
            _expressionLabel.Text = "";
            if (_leftPanelExpanded) CollapseLeftPanel();
            return;
        }

        int mainW = _expressionLabel.Width - 16;
        int leftW = LeftPanelW - 16;

        Size fullSize = TextRenderer.MeasureText(fullExpr, _expressionLabel.Font,
            new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding);

        if (fullSize.Width <= mainW) {
            _expressionLabel.Text = fullExpr;
            if (_leftPanelExpanded) CollapseLeftPanel();
            return;
        }

        if (!_leftPanelExpanded && _activeWorksheet == null) ExpandLeftPanel();

        int splitAt = 0;
        for (int i = 0; i <= fullExpr.Length; i++) {
            string tail = fullExpr.Substring(i);
            Size s = TextRenderer.MeasureText(tail, _expressionLabel.Font, new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding);
            if (s.Width <= mainW) { splitAt = i; break; }
        }
        _expressionLabel.Text = fullExpr.Substring(splitAt);

        if (_leftPanelExpanded) {
            string prefix = fullExpr.Substring(0, splitAt);
            int leftSplit = 0;
            for (int j = 0; j <= prefix.Length; j++) {
                string tail = prefix.Substring(j);
                Size s = TextRenderer.MeasureText(tail, _leftExpressionLabel.Font, new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding);
                if (s.Width <= leftW) { leftSplit = j; break; }
            }
            _leftExpressionLabel.Text = prefix.Substring(leftSplit);
        }
    }

    private void ExpandLeftPanel() {
        if (_leftPanelExpanded) return;
        _leftPanelExpanded = true;
        int shift = LeftPanelW;
        foreach (Control c in this.Controls) {
            if (c == _leftPanel) continue;
            c.Left += shift;
        }
        this.ClientSize = new Size(this.ClientSize.Width + shift, this.ClientSize.Height);
        _leftPanel.Visible = true;
    }

    private void CollapseLeftPanel() {
        if (!_leftPanelExpanded) return;
        _leftPanelExpanded = false;
        _leftPanel.Visible = false;
        int shift = LeftPanelW;
        foreach (Control c in this.Controls) {
            if (c == _leftPanel) continue;
            c.Left -= shift;
        }
        this.ClientSize = new Size(this.ClientSize.Width - shift, this.ClientSize.Height);
        _leftExpressionLabel.Text = "";
    }

    private string FormatNumber(double d) {
        if (double.IsNaN(d) || double.IsInfinity(d)) return "Error";
        if (Math.Abs(d) < 1e-15 && d != 0) return "0";

        double rounded = Math.Round(d, 10);
        string s;
        if (Math.Abs(rounded) >= 1e15 || (Math.Abs(rounded) < 1e-6 && rounded != 0)) {
            return rounded.ToString("G10", CultureInfo.InvariantCulture);
        }
        if (Math.Abs(rounded - Math.Round(rounded)) < 1e-9) {
            long l = (long)Math.Round(rounded);
            s = l.ToString(CultureInfo.InvariantCulture);
        } else {
            s = rounded.ToString("0.##########", CultureInfo.InvariantCulture);
            if (s.Contains(".")) s = s.TrimEnd('0').TrimEnd('.');
        }

        if (_ctx.Settings.DigitGrouping) {
            int dotIndex = s.IndexOf('.');
            string intPart = dotIndex >= 0 ? s.Substring(0, dotIndex) : s;
            string fracPart = dotIndex >= 0 ? s.Substring(dotIndex) : "";
            bool negative = intPart.StartsWith("-");
            if (negative) intPart = intPart.Substring(1);
            string grouped = "";
            for (int i = 0; i < intPart.Length; i++) {
                if (i > 0 && (intPart.Length - i) % 3 == 0) grouped += ",";
                grouped += intPart[i];
            }
            s = (negative ? "-" : "") + grouped + fracPart;
        }
        return s;
    }

    // ---- Actions ----

    private void DoCopy() {
        try {
            string raw = _display.Replace(",", "");
            Clipboard.SetText(raw);
        } catch { }
    }

    private void DoInsert() {
        string raw = _display.Replace(",", "");
        if (_isError) raw = "Error";

        if (_ctx.Settings.CopyOnInsert) {
            try { Clipboard.SetText(raw); } catch { }
        }

        if (_targetWindow == IntPtr.Zero) {
            MessageBox.Show("No target window captured.\n\nThe value has been copied to your clipboard.\n\nTo capture a target, close Ghost Calc, click into the window you want to send to, then reopen Ghost Calc from the tray.",
                "Ghost Calc", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        try {
            SetForegroundWindow(_targetWindow);
            Thread.Sleep(120);
            SendUnicodeString(raw);
        } catch { }

        if (_ctx.Settings.CloseAfterInsert) {
            this.Hide();
        } else {
            Timer t = new Timer();
            t.Interval = 200;
            t.Tick += (s, e) => {
                t.Stop(); t.Dispose();
                try { this.Activate(); } catch { }
            };
            t.Start();
        }
    }

    public void SetTarget(IntPtr hwnd) {
        _targetWindow = hwnd;
        StringBuilder sb = new StringBuilder(256);
        GetWindowText(hwnd, sb, 256);
        _targetTitle = sb.ToString();
        if (string.IsNullOrEmpty(_targetTitle)) _targetTitle = "(untitled)";
        if (_targetLabel != null) _targetLabel.Text = "Target: " + _targetTitle;
    }

    public void ApplySettings() {
        this.TopMost = _ctx.Settings.AlwaysOnTop;
        UpdateDisplay();
    }

    // ---- Keyboard ----

    private void CalculatorForm_KeyDown(object sender, KeyEventArgs e) {
        Control active = this.ActiveControl;
        if (active is TextBox) return;
        if (active is DateTimePicker) return;
        if (active is ComboBox) return;

        int vk = e.KeyValue;

        if (vk >= 0x60 && vk <= 0x69) { EnterDigit((char)('0' + (vk - 0x60))); e.SuppressKeyPress = true; return; }
        if (vk == 0x6B) { SetOperator("+"); e.SuppressKeyPress = true; return; }
        if (vk == 0x6D) { SetOperator("-"); e.SuppressKeyPress = true; return; }
        if (vk == 0x6A) { SetOperator("*"); e.SuppressKeyPress = true; return; }
        if (vk == 0x6F) { SetOperator("/"); e.SuppressKeyPress = true; return; }
        if (vk == 0x6E) { EnterDecimal(); e.SuppressKeyPress = true; return; }

        if (e.Shift) {
            if (vk == 0x35) { ApplyPercent();   e.SuppressKeyPress = true; return; }
            if (vk == 0x38) { SetOperator("*"); e.SuppressKeyPress = true; return; }
            if (vk == 0xBB) { SetOperator("+"); e.SuppressKeyPress = true; return; }
            if (vk >= 0x30 && vk <= 0x39) { e.SuppressKeyPress = true; return; }
        }

        if (vk >= 0x30 && vk <= 0x39) { EnterDigit((char)('0' + (vk - 0x30))); e.SuppressKeyPress = true; return; }

        switch (vk) {
            case 0xBE: EnterDecimal(); e.SuppressKeyPress = true; return;
            case 0xBD: SetOperator("-"); e.SuppressKeyPress = true; return;
            case 0xBF: SetOperator("/"); e.SuppressKeyPress = true; return;
            case 0xBB: DoEquals(); e.SuppressKeyPress = true; return;
            case 0x0D: DoEquals(); e.SuppressKeyPress = true; return;
            case 0x08: Backspace(); e.SuppressKeyPress = true; return;
            case 0x1B: ClearAll(); e.SuppressKeyPress = true; return;
        }
    }

    private void CalculatorForm_Deactivate(object sender, EventArgs e) {
        IntPtr fg = GetForegroundWindow();
        if (fg != IntPtr.Zero && fg != this.Handle) SetTarget(fg);
    }

    private void CalculatorForm_FormClosing(object sender, FormClosingEventArgs e) {
        if (!AllowClose && e.CloseReason == CloseReason.UserClosing) {
            e.Cancel = true;
            this.Hide();
            return;
        }
    }

    // ---- SendInput ----

    private void SendUnicodeString(string text) {
        if (string.IsNullOrEmpty(text)) return;
        foreach (char c in text) {
            if (c == '\r') continue;
            if (c == '\n') { SendVirtualKey(VK_RETURN); continue; }
            if (c == '\t') { SendVirtualKey(VK_TAB); continue; }
            INPUT[] inputs = new INPUT[2];
            inputs[0].type = INPUT_KEYBOARD;
            inputs[0].U.ki.wVk = 0;
            inputs[0].U.ki.wScan = (ushort)c;
            inputs[0].U.ki.dwFlags = KEYEVENTF_UNICODE;
            inputs[1].type = INPUT_KEYBOARD;
            inputs[1].U.ki.wVk = 0;
            inputs[1].U.ki.wScan = (ushort)c;
            inputs[1].U.ki.dwFlags = KEYEVENTF_UNICODE | KEYEVENTF_KEYUP;
            SendInput(2, inputs, Marshal.SizeOf(typeof(INPUT)));
        }
    }

    private void SendVirtualKey(ushort vk) {
        INPUT[] inputs = new INPUT[2];
        inputs[0].type = INPUT_KEYBOARD;
        inputs[0].U.ki.wVk = vk;
        inputs[1].type = INPUT_KEYBOARD;
        inputs[1].U.ki.wVk = vk;
        inputs[1].U.ki.dwFlags = KEYEVENTF_KEYUP;
        SendInput(2, inputs, Marshal.SizeOf(typeof(INPUT)));
    }
}

// ----------------------------------------------------------------------
// Settings dialog
// ----------------------------------------------------------------------
public class SettingsDialog : Form {
    private CheckBox _chkCloseAfter;
    private CheckBox _chkCopyOnInsert;
    private CheckBox _chkTopMost;
    private CheckBox _chkDigitGroup;

    public CalcSettings Result;

    public SettingsDialog(CalcSettings current) {
        Result = new CalcSettings();
        Result.CloseAfterInsert = current.CloseAfterInsert;
        Result.CopyOnInsert = current.CopyOnInsert;
        Result.AlwaysOnTop = current.AlwaysOnTop;
        Result.DigitGrouping = current.DigitGrouping;

        this.Text = "Ghost Calc — Settings";
        this.Icon = CalcIcon.Get();
        this.TopMost = true;
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.StartPosition = FormStartPosition.CenterScreen;
        this.ClientSize = new Size(400, 240);
        this.MinimizeBox = false; this.MaximizeBox = false; this.ShowInTaskbar = false;
        this.Font = new Font("Segoe UI", 9);
        this.BackColor = Color.FromArgb(0xFD, 0xFA, 0xF3);

        Label secInsert = new Label();
        secInsert.Text = "Insert behaviour";
        secInsert.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        secInsert.ForeColor = Color.FromArgb(0xA6, 0x7C, 0x52);
        secInsert.Location = new Point(16, 12);
        secInsert.Size = new Size(360, 20);
        this.Controls.Add(secInsert);

        _chkCloseAfter = new CheckBox();
        _chkCloseAfter.Text = "Close Ghost Calc after Insert";
        _chkCloseAfter.Location = new Point(16, 40);
        _chkCloseAfter.Size = new Size(360, 22);
        _chkCloseAfter.Checked = Result.CloseAfterInsert;
        this.Controls.Add(_chkCloseAfter);

        _chkCopyOnInsert = new CheckBox();
        _chkCopyOnInsert.Text = "Also copy the answer to clipboard on Insert";
        _chkCopyOnInsert.Location = new Point(16, 66);
        _chkCopyOnInsert.Size = new Size(360, 22);
        _chkCopyOnInsert.Checked = Result.CopyOnInsert;
        this.Controls.Add(_chkCopyOnInsert);

        Label sep = new Label();
        sep.BorderStyle = BorderStyle.Fixed3D;
        sep.Location = new Point(16, 100);
        sep.Size = new Size(368, 2);
        this.Controls.Add(sep);

        Label secView = new Label();
        secView.Text = "Display";
        secView.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        secView.ForeColor = Color.FromArgb(0xA6, 0x7C, 0x52);
        secView.Location = new Point(16, 112);
        secView.Size = new Size(360, 20);
        this.Controls.Add(secView);

        _chkTopMost = new CheckBox();
        _chkTopMost.Text = "Always on top";
        _chkTopMost.Location = new Point(16, 140);
        _chkTopMost.Size = new Size(360, 22);
        _chkTopMost.Checked = Result.AlwaysOnTop;
        this.Controls.Add(_chkTopMost);

        _chkDigitGroup = new CheckBox();
        _chkDigitGroup.Text = "Digit grouping (1,234,567)";
        _chkDigitGroup.Location = new Point(16, 166);
        _chkDigitGroup.Size = new Size(360, 22);
        _chkDigitGroup.Checked = Result.DigitGrouping;
        this.Controls.Add(_chkDigitGroup);

        Button btnSave = new Button();
        btnSave.Text = "Save";
        btnSave.Location = new Point(220, 200);
        btnSave.Size = new Size(75, 28);
        btnSave.DialogResult = DialogResult.OK;
        btnSave.Click += (s, e) => {
            Result.CloseAfterInsert = _chkCloseAfter.Checked;
            Result.CopyOnInsert = _chkCopyOnInsert.Checked;
            Result.AlwaysOnTop = _chkTopMost.Checked;
            Result.DigitGrouping = _chkDigitGroup.Checked;
        };
        this.Controls.Add(btnSave);

        Button btnCancel = new Button();
        btnCancel.Text = "Cancel";
        btnCancel.Location = new Point(303, 200);
        btnCancel.Size = new Size(75, 28);
        btnCancel.DialogResult = DialogResult.Cancel;
        this.Controls.Add(btnCancel);

        this.AcceptButton = btnSave;
        this.CancelButton = btnCancel;
    }
}

// ----------------------------------------------------------------------
// ClipLabel — right-aligned label that clips on the LEFT when text overflows
// ----------------------------------------------------------------------
public class ClipLabel : Panel {
    private string _text = "";
    public ClipLabel() {
        SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true);
    }
    public override string Text {
        get { return _text; }
        set { _text = value ?? ""; Invalidate(); }
    }
    protected override void OnPaint(PaintEventArgs e) {
        base.OnPaint(e);
        if (string.IsNullOrEmpty(_text)) return;
        e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        using (SolidBrush b = new SolidBrush(ForeColor)) {
            SizeF sz = e.Graphics.MeasureString(_text, Font);
            float x = ClientSize.Width - sz.Width - 8;
            float y = (ClientSize.Height - sz.Height) / 2f;
            e.Graphics.DrawString(_text, Font, b, x, y);
        }
    }
}